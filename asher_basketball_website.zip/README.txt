ASHER BASKETBALL WEBSITE

Files:
- index.html: the website

Before publishing:
1. Open index.html in Notepad or another text editor.
2. Search for the sample details and update anything that is wrong.
3. Add video links only after you upload real film.
4. Ask a parent/guardian to review what contact information is public.

Publish free with GitHub Pages:
1. Sign in/create a GitHub account with parent/guardian help if needed.
2. Create a NEW PUBLIC repository named exactly: YOUR-USERNAME.github.io
   Replace YOUR-USERNAME with your GitHub username.
3. Upload index.html to the top level of that repository.
4. Open the repository Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose branch main and folder /(root), then Save.
7. Wait a few minutes and visit https://YOUR-USERNAME.github.io

GitHub's official guide:
https://docs.github.com/en/pages/quickstart
